"# react-native-expo-webview-convert-website-to-app" 

Download project and run yarn init. after successfully run the init command , yarn start.
